from .user_view import UserList
from .user_view import UserDetail
