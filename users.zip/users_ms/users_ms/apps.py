from django.apps import AppConfig

class UsersMSConfig(AppConfig):
    name = 'users_ms'
